#include "prime.h"
#include <math.h>
#include <limits.h>

/*Ritorna 1 se n e� primo, 0 altrimenti.*/
unsigned short int is_prime(unsigned short int n) {
    unsigned int j = 0;
    if (n == 0 || n == 1) {
        return 0;
    }
    for (j = 2; j <= sqrt(n); j++) { // Per ottimizzare, basta controllare tutti i valori fino alla radice di n.
        if (n % j == 0) {            // Controllo se non � primo.
            return 0;
        }
    }
    return 1;
}

/* Ritorna l�n- esimo primo , contando a partire da 0.
* Se il numero e� troppo grande per essere rappresentato con un unsigned short int, ritorna 0.*/
unsigned short int nth_prime(unsigned short int n) {
    unsigned int count = 0;
    unsigned int prime = 2;
    unsigned int i;
    for (i = 3; i <= USHRT_MAX && count < n; i++) { // controllo per evitare overflow.
        if (is_prime(i)) {                          // controllo se primo.
            count++;
            prime = i;
        }
    }
    return count == n ? prime : 0;
}

/* Ritorna la successione di numeri primi.
* La prima chiamata ritorna 2, la seconda 3, ecc.
* Se il parametro reset e� diverso da 0, allora la
* successione viene resettata e la funzione ritorna 2.
* Diversamente, la funzione ritorna il primo successivo
* a quello ritornato alla chiamata precedente.
* Se il primo successivo e� troppo grande per essere
* rappresentato con un unsigned short int, la funzione
* ritorna 0 e la seccessione viene resettata.*/
unsigned short int succ_prime(int reset) {
    static unsigned short int counter = 0;
    unsigned long int i;
    if (reset != 0 || counter == 0) {
        counter = 2;
    }
    else if (counter == 2) {
        counter = 3;
    }
    else {
        for (i = counter + 2; i < USHRT_MAX && !is_prime(i); i += 2); // Controllo per evitare overflow dello short int e se non � primo, continuo a contare, altrimenti memorizzo l'ultimo num primo.
        if (i >= USHRT_MAX) counter = 0;
        else counter = i;
    }
    return counter;
}

/*Ritorna 1 se m e n sono coprimi, 0 altrimenti*/
unsigned short int co_prime(unsigned short int m, unsigned short int n) {
    unsigned int k = 0;
    unsigned int max = m > n ? n : m; // Assegnazione del valore maggiore (ottimizzazione nel ciclo)

    for (k = 2; k < max; k++) {
        if (m % k == 0 && n % k == 0) { // Se entrambi sono divisibili per lo stesso numero, allora non sono coprimi.
            return 0;
        }
    }
    return 1;
}

